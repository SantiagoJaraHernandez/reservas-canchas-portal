window.APP_CONFIG = {
  API_URL: "http://localhost:8002"
};
